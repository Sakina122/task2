# Read the file
file = open("data.txt", "r")
lines = file.readlines()
file.close()

#write the file
file = open("data2.txt", "w")
file.write("sakina fatima")
file.close
file.close() 

# Append
file = open("data2.txt", "a")
file.write("\nhow are you")  
file.close()  

# # Read the file
# file = open("data.txt", "r")
# lines = file.readlines()
# file.close()

total_lines = len(lines)
total_words = sum(len(line.split()) for line in lines)
longest_line = max(lines, key=lambda x: len(x.strip())) 


print("\nLines:", total_lines)
print("Words:", total_words)
print("Longest Line:", longest_line.strip())


