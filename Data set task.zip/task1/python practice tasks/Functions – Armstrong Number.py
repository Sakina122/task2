num = int(input("Enter a number: "))
def is_armstrong(num):
    return num == sum(int(num)**3 for num in str(num))  # 3 digits in sample input


print("Armstrong" if is_armstrong(num) else "Not Armstrong")


