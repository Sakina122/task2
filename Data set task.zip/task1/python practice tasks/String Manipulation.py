# a = '''Python is a high-level programming language that is easy to understand and learn."
# "It is widely used by beginners as well as professionals. Python is used in many fields such as web development, data science, artificial intelligence, and machine learning. It helps developers write clean and readable code." \
# "Because of its simplicity and power, Python is one of the most popular programming languages in the world.'''
# title_case_version = a.title() #title case version 
# word_count=len(a.split()) #word count
# char_count = len(a.strip()) 



# print(title_case_version) 
# print(word_count)
# print(char_count)


a = input("Enter a sentence: ")
# character count (excluding spaces)
char_count = len(a.strip())                             #len(a.replace(" ", ""))
word_count = len(a.split())
title_case = a.title()

print(char_count)
print(word_count)
print(title_case)



