# n = 10
# numbers = (7, 8, 9, 10, 11)

# # replace odd numbers with -1
# result = tuple(-10 if num % 2 != 0 else num for num in numbers)# replace odd numbers with -10
# print(result)



n = int(input("Enter elements: "))
numbers = tuple(map(int, input("Enter numbers: ").split()))


result = []

for num in numbers:
    if num % 2 != 0:
        result.append(-3) # replace odd numbers with -3
    else:
        result.append(num)


final_tuple = tuple(result)  


print(final_tuple)
