# #try:
#    # a = abc
#     #b = 0

#     ##result = a / b
#     #print(f"{result:.2}")

# #except ZeroDivisionError:
#    # print("Error: Division by zero")

# #except ValueError:
#    # print("Error: Invalid input")

# a = [("30", "2"),("10", "0"),("one", "5"),("10", "one"),("abc", "def")] # list of tuple

# for a_input, b_input in a:
#     print(f"\nTesting with inputs: a = {a_input}, b = {b_input}")
#     try:
#         a = int(a_input)
#         b = int(b_input)
#         result = a / b
#         print(f"Result: {result:.2}")
#     except ZeroDivisionError:
#         print("Error: Division by zero")
#     except ValueError:
#         print("Error: Invalid input")
try:
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))

    result = a / b
    print(f"{result:.2f}")

except ZeroDivisionError:
    print("Error: Division by zero")

except ValueError:
    print("Error: Invalid input")


