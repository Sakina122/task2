
# n = 10


# for i in range(1, n + 1): #loop in each row
    
#     for j in range(1, i + 1): #add number for current into 1
#         print(j, end="")  #print number in each row
#     print() 

# take input
n = int(input("Enter element: "))


for i in range(1, n + 1): # we use for loop 
    for j in range(1, i + 1):
        print(j, end="")
    print()

