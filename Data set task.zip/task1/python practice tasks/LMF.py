n = int(input("Enter a #elements: "))
numbers = list(map(int, input("Enter  number: ").split()))



# Use filter to keep even numbers, then map to square them
result = list(map(lambda x: x**2, filter(lambda x: x % 2 == 0, numbers)))

print(result)

