# n=6
# colours=["red", "yellow", "pink", "brown", "blue","ox"] #create list of colours #and it contain 5 strings
# result = [c.upper() for c in colours if len(c) > 3] # take colours name more than 3 # c.upper giver selected names in upper
# print(result)



n = int(input("Enter number of colours: "))

strings = []
for i in range(n):
    b = input(f"Enter colour  {i+1}: ")
    strings.append(b)

# list comprehension to filter and convert
result = [c.upper() for c in strings if len(c) > 3]

print(result)
