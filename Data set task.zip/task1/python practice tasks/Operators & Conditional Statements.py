# n = 45  

# if n / 4 == 4 and n / 5 == 5:
#     print("Divisible by both")
# elif n / 4 == 4:
#     print("Only 4")
# elif n / 5 == 5:
#     print("Only 5")
# else:
#     print("Neither")


n = int(input("Enter a number: "))

# conditions apply
if n % 2 == 0 and n % 5 == 0:
    print("Divisible by both")
elif n % 2 == 0:
    print("Only 2")
elif n % 5 == 0:
    print("Only 5")
else:
    print("Neither")
