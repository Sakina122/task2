
# a =20
# b=67

# # List to store prime numbers
# prime_numbers = []

# # Loop through each number in the range
# for num in range(a, b + 1):
#     if num > 1:  # 1 is not prime
#         is_prime = True
#         # Check for divisors from 2 to sqrt(num)
#         for i in range(2, int(num ** 0.5) + 1):
#             if num % i == 0:
#                 is_prime = False
#                 break
#         if is_prime:
#             prime_numbers.append(num)

# # Print the list of prime numbers
# print(prime_numbers)

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

primes = []

for num in range(a, b + 1):
    if num > 1:
        is_prime = True
        for i in range(2, num):
            if num % i == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(num)

print(primes)




