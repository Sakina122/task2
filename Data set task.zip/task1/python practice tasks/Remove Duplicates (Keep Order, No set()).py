# # Input number of elements
# n = 8

# # Input list of numbers separated by space
# nums = ("1 1 2 3 4 4 5 6").split()

# # Convert each number from string to int
# nums = [int(num) for num in nums]

# # Remove duplicates while keeping original order
# unique_nums = []
# for num in nums:
#     if num not in unique_nums:
#         unique_nums.append(num)

# # Print the final list
# print(unique_nums)


n = int(input("Enter number of elements: "))

numbers = list(map(int, input("Enter the numbers: ").split()))

# remove duplicates
result = []
for num in numbers:
    if num not in result:
        result.append(num)


print(result)

