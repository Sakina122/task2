# a=2
# b=4
# c=6
# d=8
# x=min('2','4','6','8')
# y=max('2','4','6','8')
# thislist = [2,4,6,8]
# average = 34/5

# print(a+b+c+d) #SUM
# print(x) #min
# print(y) #max
# print(thislist)#list
# print(format(average))#average

# input number of elements
a= int(input("Enter number of elements:"))

# input list of integers
numbers = list(map(int, input("Enter the numbers: ").split()))

# calculate values
minimum = min(numbers)
maximum = max(numbers)
total = sum(numbers)
average = total /a
sorted_list = sorted(numbers)

# print results
print(minimum)
print(maximum)
print(total)
print(average)
print(sorted_list)




