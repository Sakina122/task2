class BankAccount:
    def __init__(self, name, balance):
        self.name = name
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        print(f"Deposit successful. Balance: {self.balance}")

    def withdraw(self, amount):
        if amount > self.balance:
            print("Insufficient balance")
        else:
            self.balance -= amount
            print(f"Withdraw successful. Balance: {self.balance}")

    def display(self):
        print(f"Account: {self.name}, Balance: {self.balance}")



name = input("enter name:")
balance = int(input("enter balance:"))
deposit_amount = int(input("enter deposit amount:"))
withdraw_amount = int(input("enter withdraw amount:"))


account = BankAccount(name, balance) # create account

account.deposit(deposit_amount)
account.withdraw(withdraw_amount)
account.display()

