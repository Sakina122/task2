# # # input string
# # s = 'A man a plan a canal Panama'
# # d= 'HELLO GIRL'


# # # remove spaces and convert to lowercase
# # clean_s = s.replace(" ", "").lower()

# # # check palindrome
# if clean_s == clean_s[::-1]:
#     print("Palindrome")
# else:
#     print("Not Palindrome")


text = input("Enter a sentence: ")

# remove spaces and convert to lowercase
clean_text = text.replace(" ", "").lower()

# check palindrome
if clean_text == clean_text[::-1]: #print valce in reverse slicing
    print("Palindrome")
else:
    print("Not Palindrome")

# n= (input("Enter a string: "))
# rev= ''
# for char in n:
#     rev = char + rev
#     if n ==rev:
#         print("Palindrome")
# else:
#         print("Not Palindrome")



