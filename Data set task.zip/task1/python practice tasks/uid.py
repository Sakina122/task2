
# set1 = {1, 2, 3, 4, 5, 6}
# set2 = {2, 8, 1, 5, 11, 12}

# print("Union:", set1.union(set2)) # print union
# print("Intersection:", set1.intersection(set2)) # print intersection
# print("Difference (set1 - set2):", set1.difference(set2)) # print difference (set1 - set2)


n1 = int(input("Enter number of element in set 1: "))

set1 = set(map(int, input("Enter elements of set 1: ").split()))

n2 = int(input("Enter number of element in set 2: "))

set2 = set(map(int, input("Enter elements of set 2: ").split()))

print(set1.union(set2))
print(set1.intersection(set2))
# print(set1.difference(set2))
print(set2.difference(set1))