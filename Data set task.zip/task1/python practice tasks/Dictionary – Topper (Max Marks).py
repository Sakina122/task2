# n = 2

# students = {} # create empty dictionary to store name and marks

# students["Eddi"] = 20
# students["John"] = 30

# topper_name = max(students, key=students.get) #use get key for give the marks to both students and max key for max marks
# topper_marks = students[topper_name]
# print("Topper:", topper_name, topper_marks)

n = int(input("Enter number of students: "))

# variables to store topper
top_name = ""
top_marks = -1


for i in range(2):# we use for loop
    data = input(f"Enter name and marks for student {i+1}: ")
    name, marks = data.split()
    marks = int(marks)

    if marks > top_marks:
        top_marks = marks
        top_name = name
    print("Topper:", top_name, top_marks)
    
