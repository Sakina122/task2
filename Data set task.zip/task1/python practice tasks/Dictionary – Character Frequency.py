
# text = "hello beautiful"


# char_freq = {} # empty dictionary

# # loop through each character
# for char in text:
#     if char != " ":       # ignore spaces
#         if char in char_freq:
#             char_freq[char] += 1
#         else:
#             char_freq[char] = 1

# # print result
# print(char_freq)
# take user input
text = input("Enter text: ")
text = text.replace(" ", "")
dictionary={} # empty dictionary built

for ch in text:
    if ch in dictionary:
        dictionary[ch] +=1
    else:
                dictionary[ch] =1



print( dictionary)


