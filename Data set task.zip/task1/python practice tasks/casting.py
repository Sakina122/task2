# a = 34
# b = 2.0

# c = float(a)
# d = float(b)

# print(c + d)5



a = input("Enter first number: ")
b = input("Enter second number: ")
sum_result = float(a) + float(b)
print("Sum:", sum_result)
