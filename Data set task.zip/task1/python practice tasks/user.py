# name = "Haider"
# age = 17

# print(f"Hello {name}, you will be {age + 1} next year.")


name = input("Enter your name: ")
age = int(input("Enter your age: "))
next_age = age + 1 # calculate next year age

print(f"Hello {name}, you will be {next_age} next year.")

